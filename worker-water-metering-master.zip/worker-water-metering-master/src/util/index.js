const file_data = {
  json: {
    code: 200,
    status: true,
    message: "Successfully Loaded Request",
    data: [],
  },
  json_file: {
      code: 200,
      status: true,
      message: "Successfully Loaded Request",
    },
};

module.exports = {
  file_data,
};
